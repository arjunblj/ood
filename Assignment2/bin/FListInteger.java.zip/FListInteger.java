
abstract class FListInteger {

    // ----- BASIC CREATORS -------------------------------
    
    /**
     * Produces an instance of this class
     */
    public static FListInteger emptyList() {
        return new EmptyList();
    }
    
    /**
     * adds the given n to the given FListInteger
     * @param n the given n 
     */
    public static FListInteger add(FListInteger l, int n) {
        return new Add(l, n);
    }
    
    // ----- OTHER CREATORS -------------------------------
    
    /**
     * is the given list empty?
     */
    public static boolean isEmpty(FListInteger l) {
        return l.isEmptyMethod();
    }
    
    abstract boolean isEmptyMethod();
    
    /**
     * fetches given index from list
     */
    public static int get(FListInteger l, int n) {
        return l.getMethod(n);
    }
    
    abstract int getMethod(int n);
    
    /**
     * sets the given value x0 at the index x in FListInteger
     */    
    public static FListInteger set(FListInteger l, int n, Integer n0) {
        return l.setMethod(n, n0);
    }
    
    abstract FListInteger setMethod(int n, Integer n0);
    
    /**
     * produces the size of the given list
     */
    public static int size(FListInteger l) {
        return l.sizeMethod();
    }
    
    abstract int sizeMethod();
    
    /**
     * turns given list into a String
     */    
    public abstract String toString();
    
    /**
     * checks if the given list and this list are equal 
     */
    public abstract boolean equals(Object x);
    
    public abstract int hashCode();
}

class EmptyList extends FListInteger {
    EmptyList() { }
    
    /**
     * Produces an instance of this class
     */
    public static FListInteger emptyList() {
        return new EmptyList();
    }
    
    /**
     * checks if list is empty or not
     */
    public boolean isEmptyMethod() {
        return true;
    }
    
    /**
     * fetches given index from the list
     */
    public int getMethod(int n) {
        throw new RuntimeException("Nothing is in an empty list.");
    }
    
    /**
     * sets the given value x0 at the index x in FListInteger
     */    
    public FListInteger setMethod(int n, Integer n0) {
        throw new RuntimeException("Nothing to set in an empty list.");
    }
    
    /**
     * produces size of given list
     */
    public int sizeMethod() {
        return 0;
    }
    
    /**
     * turns given list into a String
     */
    public String toString() {
        return "[]";
    }
    
    /**
     * checks if the given list and this list are equal 
     */
    public boolean equals(Object x) {
        return true;
    }
    
    public int hashCode() {
        return 1;
    }
}

class Add extends FListInteger {
    FListInteger l;
    Integer n;
    
    Add(FListInteger l, Integer n) {
        this.l = l;
        this.n = n;
    }
    
    /**
     * checks if the given list is empty
     */    
    public boolean isEmptyMethod() {
        return false;
    }
    
    /**
     * fetches given index from the list
     */
    public int getMethod(int x) {
        if (x == 0) {
            return this.n;
        }
        else {
            return this.l.getMethod(x - 1);
        }
    }
    
    /**
     * sets the given value x0 at the index x in FListInteger
     */
    public FListInteger setMethod(int x, Integer x0) {
        if (x == 0) {
            return FListInteger.add(this.l, x0);
        }
        else {
            return FListInteger.add(FListInteger.set(this.l, x - 1, x0), x);
        }
    }
    
    /**
     * produces size of given list
     */
    public int sizeMethod() {
        return 1 + FListInteger.size(this.l);
    }
    
    /**
     * turns given list into a String
     */
    public String toString() {
        if (FListInteger.isEmpty(this.l)) {
            return "[" + n.toString() + "]";
        }
        else {
            return "[" + n.toString() + ", "
                    + l.toString().substring(1, l.toString().length());
        }
    }
    
    /**
     * checks if the given obj and this list are equal 
     */
    public boolean equals(Object o) {
        return true;
        }
    
    public int hashCode() {
        return 1;
    }
}